package org.zerock.myapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class MainController {

    @FXML
    private TextField searchField; // 검색어 입력을 위한 TextField

    @FXML
    private ListView<String> resultListView; // 검색 결과를 보여주기 위한 ListView

    private Stage primaryStage; // 주 스테이지
    private Connection connection; // 데이터베이스 연결 객체

    // 생성자
    public MainController(Stage primaryStage) {
        this.primaryStage = primaryStage;
        initializeDatabase(); // 데이터베이스 초기화 메서드 호출
    }

    // 데이터베이스 초기화 메서드
    private void initializeDatabase() {
        try {
            // 데이터베이스 연결 설정
            String url = "jdbc:oracle:thin:@localhost:1521/XEPDB1"; // 데이터베이스 URL
            String username = "SCOTT"; // 데이터베이스 사용자명
            String password = "oracle"; // 데이터베이스 암호

            connection = DriverManager.getConnection(url, username, password); // 연결 생성
        } catch (SQLException e) {
            e.printStackTrace(); // 오류 발생 시 출력
        }
    }

    // 쉼표 추가 버튼 핸들러
    @FXML
    private void handleCommaAction() {
        appendText(",");
    }

    // 숫자 기호 추가 버튼 핸들러
    @FXML
    private void handleNumberSymbolAction() {
        appendText("#");
    }

    // 점 추가 버튼 핸들러
    @FXML
    private void handleDotAction() {
        appendText(".");
    }

    // 공백 추가 버튼 핸들러
    @FXML
    private void handleSpaceAction() {
        appendText(" ");
    }

    // 대문자 변환 버튼 핸들러
    @FXML
    private void handleShiftAction() {
        // ListView의 모든 항목을 대문자로 변환
        ObservableList<String> items = resultListView.getItems();
        for (int i = 0; i < items.size(); i++) {
            items.set(i, items.get(i).toUpperCase());
        }
        resultListView.setItems(items); // 변환된 항목을 ListView에 설정
    }

    // 백스페이스 핸들러
    @FXML
    private void handleBackspaceAction() {
        String text = searchField.getText(); // 현재 검색어 가져오기
        if (!text.isEmpty()) {
            searchField.setText(text.substring(0, text.length() - 1)); // 마지막 글자 삭제 후 설정
        }
    }

    // 키 버튼 핸들러
    @FXML
    private void handleKeyAction(javafx.event.ActionEvent event) {
        Button button = (Button) event.getSource(); // 이벤트 발생 버튼 가져오기
        appendText(button.getText()); // 버튼의 텍스트를 검색어에 추가
    }

    // 검색 버튼 핸들러
    @FXML
    private void handleSearchAction() {
        String query = searchField.getText().trim(); // 검색어 가져오기 (공백 제거)
        if (!query.isEmpty()) { // 검색어가 비어있지 않은 경우
            List<String> searchResults = searchEmployees(query); // 검색어로 직원 검색
            ObservableList<String> observableResults = FXCollections.observableArrayList(searchResults); // ObservableList로 변환
            resultListView.setItems(observableResults); // ListView에 검색 결과 설정
        } else {
            resultListView.getItems().clear(); // 검색어가 비어있는 경우 ListView 초기화
        }
    }

    // 검색어를 TextField에 추가하는 메서드
    private void appendText(String text) {
        String currentText = searchField.getText(); // 현재 검색어 가져오기
        searchField.setText(currentText + text); // 현재 검색어 뒤에 추가된 텍스트 추가
    }

    // 직원을 검색하는 메서드
    private List<String> searchEmployees(String query) {
        List<String> results = new ArrayList<>(); // 검색 결과를 담을 리스트

        String sql = "SELECT first_name FROM employees WHERE first_name LIKE ?"; // SQL 쿼리

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, query + "%"); // LIKE 연산을 위한 검색어 설정
            ResultSet resultSet = statement.executeQuery(); // 쿼리 실행 및 결과셋 가져오기
            while (resultSet.next()) {
                String firstName = resultSet.getString("first_name"); // 결과셋에서 first_name 가져오기
                results.add(firstName); // 결과 리스트에 추가
            }
        } catch (SQLException e) {
            e.printStackTrace(); // 오류 발생 시 출력
        }

        return results; // 검색 결과 반환
    }
}
