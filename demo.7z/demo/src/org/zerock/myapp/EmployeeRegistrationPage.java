package testest;

import javax.swing.*;
import java.awt.*;

public class EmployeeRegistrationPage {
    public static void main(String[] args) {
        JFrame frame = new JFrame("신규 사원 등록");
        frame.setSize(360, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel nameLabel = new JLabel("이름:");
        nameLabel.setBounds(30, 30, 100, 30);
        frame.add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(140, 30, 200, 30);
        frame.add(nameField);

        JLabel birthDateLabel = new JLabel("생년월일:");
        birthDateLabel.setBounds(30, 80, 100, 30);
        frame.add(birthDateLabel);

        JComboBox<String> yearComboBox = new JComboBox<>();
        for (int year = 1925; year <= 2024; year++) {
            yearComboBox.addItem(String.valueOf(year));
        }
        yearComboBox.setBounds(140, 80, 80, 30);
        frame.add(yearComboBox);

        JComboBox<String> monthComboBox = new JComboBox<>();
        for (int month = 1; month <= 12; month++) {
            monthComboBox.addItem(String.valueOf(month));
        }
        monthComboBox.setBounds(230, 80, 60, 30);
        frame.add(monthComboBox);

        JComboBox<String> dayComboBox = new JComboBox<>();
        for (int day = 1; day <= 31; day++) {
            dayComboBox.addItem(String.valueOf(day));
        }
        dayComboBox.setBounds(300, 80, 60, 30);
        frame.add(dayComboBox);

        JLabel addressLabel = new JLabel("주소:");
        addressLabel.setBounds(30, 130, 100, 30);
        frame.add(addressLabel);

        JTextField addressField = new JTextField();
        addressField.setBounds(140, 130, 200, 30);
        frame.add(addressField);

        JLabel phoneNumberLabel = new JLabel("전화번호:");
        phoneNumberLabel.setBounds(30, 180, 100, 30);
        frame.add(phoneNumberLabel);

        JTextField phoneNumberField = new JTextField();
        phoneNumberField.setBounds(140, 180, 200, 30);
        frame.add(phoneNumberField);

        JLabel emailLabel = new JLabel("이메일:");
        emailLabel.setBounds(30, 230, 100, 30);
        frame.add(emailLabel);

        JTextField customEmailField = new JTextField();
        customEmailField.setBounds(140, 230, 200, 30);
        frame.add(customEmailField);

        String[] emailDomains = {"@gmail.com", "@naver.com", "@hanmail.net", "@icloud.com", "@hotmail.com", "@outlook.com", "@yahoo.com", "@daum.net", "@nate.com", "직접입력"};
        JComboBox<String> emailComboBox = new JComboBox<>(emailDomains);
        emailComboBox.setBounds(140, 280, 120, 30);
        frame.add(emailComboBox);

        JLabel departmentLabel = new JLabel("부서:");
        departmentLabel.setBounds(30, 330, 100, 30);
        frame.add(departmentLabel);

        JTextField departmentField = new JTextField();
        departmentField.setBounds(140, 330, 200, 30);
        frame.add(departmentField);

        JLabel hireDateLabel = new JLabel("입사일:");
        hireDateLabel.setBounds(30, 380, 100, 30);
        frame.add(hireDateLabel);

        JComboBox<String> hireYearComboBox = new JComboBox<>();
        for (int year = 1925; year <= 2024; year++) {
            hireYearComboBox.addItem(String.valueOf(year));
        }
        hireYearComboBox.setBounds(140, 380, 80, 30);
        frame.add(hireYearComboBox);

        JComboBox<String> hireMonthComboBox = new JComboBox<>();
        for (int month = 1; month <= 12; month++) {
            hireMonthComboBox.addItem(String.valueOf(month));
        }
        hireMonthComboBox.setBounds(230, 380, 60, 30);
        frame.add(hireMonthComboBox);

        JComboBox<String> hireDayComboBox = new JComboBox<>();
        for (int day = 1; day <= 31; day++) {
            hireDayComboBox.addItem(String.valueOf(day));
        }
        hireDayComboBox.setBounds(300, 380, 60, 30);
        frame.add(hireDayComboBox);

        JLabel noteLabel = new JLabel("특이사항:");
        noteLabel.setBounds(30, 430, 100, 30);
        frame.add(noteLabel);

        JTextArea noteArea = new JTextArea();
        noteArea.setBounds(140, 430, 200, 100);
        frame.add(noteArea);

        JButton registerButton = new JButton("등록");
        registerButton.setBounds(30, 550, 100, 40);
        frame.add(registerButton);

        JButton cancelButton = new JButton("취소");
        cancelButton.setBounds(140, 550, 100, 40);
        frame.add(cancelButton);

        frame.setVisible(true);
    }
}
