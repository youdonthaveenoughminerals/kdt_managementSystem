package testest;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class dffdf1 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Employee Management System");
        frame.setSize(360, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("File");
        JMenuItem menuItem = new JMenuItem("Exit");
        menu.add(menuItem);
        menuBar.add(menu);
        frame.setJMenuBar(menuBar);

        JButton departmentButton = new JButton("Department");
        departmentButton.setBounds(30, 30, 300, 80);
        frame.add(departmentButton);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(0, 1));
        ArrayList<JButton> buttonList = new ArrayList<>();

        for (int i = 1; i <= 20; i++) {
            JButton button = new JButton("Dep" + i);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // 해당 부서 페이지로 이동
                    String departmentName = button.getText();
                    openDepartmentPage(departmentName);
                }
            });
            buttonList.add(button);
            panel.add(button);
        }

        JScrollPane scrollPane = new JScrollPane(panel);
        scrollPane.setBounds(30, 130, 300, 350);
        frame.add(scrollPane);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        frame.setVisible(true);
    }

    // 부서 페이지 열기
    private static void openDepartmentPage(String departmentName) {
        JFrame departmentFrame = new JFrame(departmentName);
        departmentFrame.setSize(360, 600);
        departmentFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        departmentFrame.setLayout(null);

        JButton registerButton = new JButton("신규 사원 등록");
        registerButton.setBounds(30, 450, 280, 80);
        departmentFrame.add(registerButton);

        departmentFrame.setVisible(true);
    }
}
