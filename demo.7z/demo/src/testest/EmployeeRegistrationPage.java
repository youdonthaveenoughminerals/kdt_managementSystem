package testest;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class EmployeeRegistrationPage extends Application {
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("신규 사원 등록");

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(10);
        grid.setHgap(10);

        Label nameLabel = new Label("이름:");
        GridPane.setConstraints(nameLabel, 0, 0);
        TextField nameField = new TextField();
        GridPane.setConstraints(nameField, 1, 0);

        Label birthDateLabel = new Label("생년월일:");
        GridPane.setConstraints(birthDateLabel, 0, 1);
        ComboBox<String> yearComboBox = new ComboBox<>();
        for (int year = 1925; year <= 2024; year++) {
            yearComboBox.getItems().add(String.valueOf(year));
        }
        GridPane.setConstraints(yearComboBox, 1, 1);
        ComboBox<String> monthComboBox = new ComboBox<>();
        for (int month = 1; month <= 12; month++) {
            monthComboBox.getItems().add(String.valueOf(month));
        }
        GridPane.setConstraints(monthComboBox, 2, 1);
        ComboBox<String> dayComboBox = new ComboBox<>();
        for (int day = 1; day <= 31; day++) {
            dayComboBox.getItems().add(String.valueOf(day));
        }
        GridPane.setConstraints(dayComboBox, 3, 1);

        Label addressLabel = new Label("주소:");
        GridPane.setConstraints(addressLabel, 0, 2);
        TextField addressField = new TextField();
        GridPane.setConstraints(addressField, 1, 2);

        Label phoneNumberLabel = new Label("전화번호:");
        GridPane.setConstraints(phoneNumberLabel, 0, 3);
        TextField phoneNumberField = new TextField();
        GridPane.setConstraints(phoneNumberField, 1, 3);

        Label emailLabel = new Label("이메일:");
        GridPane.setConstraints(emailLabel, 0, 4);
        TextField customEmailField = new TextField();
        GridPane.setConstraints(customEmailField, 1, 4);
        ComboBox<String> emailComboBox = new ComboBox<>();
        String[] emailDomains = {"@gmail.com", "@naver.com", "@hanmail.net", "@icloud.com", "@hotmail.com", "@outlook.com", "@yahoo.com", "@daum.net", "@nate.com", "직접입력"};
        emailComboBox.getItems().addAll(emailDomains);
        GridPane.setConstraints(emailComboBox, 1, 5);

        Label departmentLabel = new Label("부서:");
        GridPane.setConstraints(departmentLabel, 0, 6);
        TextField departmentField = new TextField();
        GridPane.setConstraints(departmentField, 1, 6);

        Label hireDateLabel = new Label("입사일:");
        GridPane.setConstraints(hireDateLabel, 0, 7);
        ComboBox<String> hireYearComboBox = new ComboBox<>();
        for (int year = 1925; year <= 2024; year++) {
            hireYearComboBox.getItems().add(String.valueOf(year));
        }
        GridPane.setConstraints(hireYearComboBox, 1, 7);
        ComboBox<String> hireMonthComboBox = new ComboBox<>();
        for (int month = 1; month <= 12; month++) {
            hireMonthComboBox.getItems().add(String.valueOf(month));
        }
        GridPane.setConstraints(hireMonthComboBox, 2, 7);
        ComboBox<String> hireDayComboBox = new ComboBox<>();
        for (int day = 1; day <= 31; day++) {
            hireDayComboBox.getItems().add(String.valueOf(day));
        }
        GridPane.setConstraints(hireDayComboBox, 3, 7);

        Label noteLabel = new Label("특이사항:");
        GridPane.setConstraints(noteLabel, 0, 8);
        TextArea noteArea = new TextArea();
        noteArea.setPrefHeight(100);
        GridPane.setConstraints(noteArea, 1, 8, 3, 1);

        Button registerButton = new Button("등록");
        GridPane.setConstraints(registerButton, 0, 9);
        Button cancelButton = new Button("취소");
        GridPane.setConstraints(cancelButton, 1, 9);

        grid.getChildren().addAll(nameLabel, nameField, birthDateLabel, yearComboBox, monthComboBox, dayComboBox,
                addressLabel, addressField, phoneNumberLabel, phoneNumberField, emailLabel, customEmailField, emailComboBox,
                departmentLabel, departmentField, hireDateLabel, hireYearComboBox, hireMonthComboBox, hireDayComboBox,
                noteLabel, noteArea, registerButton, cancelButton);

        Scene scene = new Scene(grid, 360, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
