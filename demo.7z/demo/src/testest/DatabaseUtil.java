package testest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:orcl"; // Oracle 데이터베이스 URL
    private static final String USER = "xepdb1"; // 데이터베이스 사용자 이름
    private static final String PASSWORD = "oracle"; // 데이터베이스 비밀번호

    static {
        try {
            // Oracle JDBC 드라이버 로드
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("Oracle JDBC 드라이버를 로드하는데 실패했습니다.", e);
        }
    }

    public static Connection getConnection() throws SQLException {
        // 데이터베이스 연결 설정 및 반환
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
