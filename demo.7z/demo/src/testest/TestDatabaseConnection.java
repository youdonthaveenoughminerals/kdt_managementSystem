package testest;

import java.sql.Connection;
import java.sql.SQLException;

public class TestDatabaseConnection {
    public static void main(String[] args) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            if (conn != null) {
                System.out.println("데이터베이스 연결 성공");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
