package testest;

public class Employee {
    private String name;
    private String birthDate;
    private String address;
    private String phoneNumber;
    private String email;
    private String department;
    private String hireDate;
    private String note;

    public Employee(String name, String birthDate, String address, String phoneNumber, String email,
                    String department, String hireDate, String note) {
        this.name = name;
        this.birthDate = birthDate;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.department = department;
        this.hireDate = hireDate;
        this.note = note;
    }

    public String getName() {
        return name;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getDepartment() {
        return department;
    }

    public String getHireDate() {
        return hireDate;
    }

    public String getNote() {
        return note;
    }

    @Override
    public String toString() {
        return name;
    }
}
