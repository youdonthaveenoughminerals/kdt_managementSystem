package testest;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Stack;

public class EmployeeManagementSystemRegistration extends Application {

    // 필드로 컨트롤들을 선언
    private TextField nameField;
    private ComboBox<String> yearComboBox;
    private ComboBox<String> monthComboBox;
    private ComboBox<String> dayComboBox;
    private TextField addressField;
    private TextField phoneNumberField;
    private TextField customEmailField;
    private ComboBox<String> emailComboBox;
    private TextField departmentField;
    private ComboBox<String> hireYearComboBox;
    private ComboBox<String> hireMonthComboBox;
    private ComboBox<String> hireDayComboBox;
    private TextArea noteArea;

    private Stack<Scene> sceneStack = new Stack<>();

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Employee Management System");
        primaryStage.setWidth(360);
        primaryStage.setHeight(600);

        MenuBar menuBar = new MenuBar();
        javafx.scene.control.Menu menu = new javafx.scene.control.Menu("File");
        MenuItem menuItem = new MenuItem("Exit");
        menu.getItems().add(menuItem);
        menuBar.getMenus().add(menu);

        Button departmentButton = new Button("Department");
        departmentButton.setPrefSize(300, 80);

        VBox root = new VBox();
        root.getChildren().addAll(menuBar, departmentButton);

        ArrayList<Button> buttonList = new ArrayList<>();

        for (int i = 1; i <= 20; i++) {
            Button button = new Button("Dep" + i);
            button.setPrefSize(300, 30);
            button.setOnAction(event -> openDepartmentPage(button.getText(), primaryStage));
            buttonList.add(button);
            root.getChildren().add(button);
        }

        ScrollPane scrollPane = new ScrollPane();
        VBox panel = new VBox();
        panel.setSpacing(5);
        panel.getChildren().addAll(buttonList);
        scrollPane.setContent(panel);
        scrollPane.setPrefSize(300, 350);

        root.getChildren().add(scrollPane);

        // "이전" 버튼 추가
        Button backButton = new Button("이전");
        backButton.setPrefSize(300, 40);
        backButton.setDisable(true); // 첫 페이지에서는 비활성화
        root.getChildren().add(backButton);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void openDepartmentPage(String departmentName, Stage primaryStage) {
        VBox root = new VBox();

        Button departmentButton = new Button(departmentName);
        departmentButton.setPrefSize(300, 80);
        root.getChildren().add(departmentButton);

        ArrayList<Button> employeeButtonList = new ArrayList<>();

        for (int i = 1; i <= 50; i++) {
            Button employeeButton = new Button("Employee" + i);
            employeeButtonList.add(employeeButton);
            root.getChildren().add(employeeButton);
        }

        ScrollPane scrollPane = new ScrollPane();
        VBox panel = new VBox();
        panel.setSpacing(5);
        panel.getChildren().addAll(employeeButtonList);
        scrollPane.setContent(panel);
        scrollPane.setPrefSize(300, 280);
        root.getChildren().add(scrollPane);

        // registerButton의 사용되는 컨트롤들을 초기화
        nameField = new TextField();
        yearComboBox = new ComboBox<>();
        monthComboBox = new ComboBox<>();
        dayComboBox = new ComboBox<>();
        addressField = new TextField();
        phoneNumberField = new TextField();
        customEmailField = new TextField();
        emailComboBox = new ComboBox<>();
        departmentField = new TextField();
        hireYearComboBox = new ComboBox<>();
        hireMonthComboBox = new ComboBox<>();
        hireDayComboBox = new ComboBox<>();
        noteArea = new TextArea();

        Button registerButton = new Button("신규 사원 등록");
        registerButton.setPrefSize(300, 80);
        registerButton.setOnAction(event -> {
            String name = nameField.getText();
            String birthDate = yearComboBox.getValue() + "-" + monthComboBox.getValue() + "-" + dayComboBox.getValue();
            String address = addressField.getText();
            String phoneNumber = phoneNumberField.getText();
            String email = customEmailField.getText() + emailComboBox.getValue();
            String department = departmentField.getText();
            String hireDate = hireYearComboBox.getValue() + "-" + hireMonthComboBox.getValue() + "-" + hireDayComboBox.getValue();
            String note = noteArea.getText();

            try (Connection conn = DatabaseUtil.getConnection()) {
                String sql = "INSERT INTO employees (name, birth_date, address, phone_number, email, department, hire_date, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, name);
                pstmt.setString(2, birthDate);
                pstmt.setString(3, address);
                pstmt.setString(4, phoneNumber);
                pstmt.setString(5, email);
                pstmt.setString(6, department);
                pstmt.setString(7, hireDate);
                pstmt.setString(8, note);
                pstmt.executeUpdate();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("등록 성공");
                alert.setHeaderText(null);
                alert.setContentText("신규 사원이 성공적으로 등록되었습니다.");
                alert.showAndWait();
            } catch (SQLException e) {
                e.printStackTrace();
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("등록 실패");
                alert.setHeaderText(null);
                alert.setContentText("신규 사원 등록에 실패했습니다.");
                alert.showAndWait();
            }
        });
        root.getChildren().add(registerButton);

        // "이전" 버튼 추가
        Button backButton = new Button("이전");
        backButton.setPrefSize(300, 40);
        backButton.setOnAction(event -> {
            if (!sceneStack.isEmpty()) {
                primaryStage.setScene(sceneStack.pop());
            }
        });
        root.getChildren().add(backButton);

        Scene scene = new Scene(root);

        // 현재 씬을 스택에 저장
        sceneStack.push(primaryStage.getScene());

        primaryStage.setScene(scene);
    }

    private void initializeComboBoxes() {
        // ComboBox 초기화
        yearComboBox.getItems().addAll("1990", "1991", "1992", "1993");
        monthComboBox.getItems().addAll("01", "02", "03", "04");
        dayComboBox.getItems().addAll("01", "02", "03", "04");

        hireYearComboBox.getItems().addAll("2020", "2021", "2022", "2023");
        hireMonthComboBox.getItems().addAll("01", "02", "03", "04");
        hireDayComboBox.getItems().addAll("01", "02", "03", "04");

        emailComboBox.getItems().addAll("@gmail.com", "@yahoo.com", "@hotmail.com");
    }
}
