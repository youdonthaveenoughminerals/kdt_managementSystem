/**
 * 
 */
/**
 * 
 */
module demo {
	requires javafx.graphics;
	requires javafx.controls;
	requires java.sql;
	
	exports testest to javafx.graphics;
}